from distutils.core import setup

setup(
	name='MyFirstModule',
	author='abhinavr8',
	author_email='abhinav.ralhan@st.niituniversity.in',
	version='0.1dev',
	packages=['abhinavPY',],
	license='Creative Commons Attribution-Noncommercial-Share Alike license',
	long_description=open('README.txt').read(),
)
